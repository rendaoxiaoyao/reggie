create definer = root@localhost view recordview as
select `r`.`id`                                       AS `id`,
       `m`.`name`                                     AS `memberName`,
       `b`.`name`                                     AS `bookName`,
       date_format(`r`.`rentDate`, '%Y-%m-%d')        AS `rentDate`,
       date_format(`r`.`backDate`, '%Y-%m-%d')        AS `backDate`,
       (`r`.`rentDate` + interval `mt`.`keepDay` day) AS `returnDate`,
       `r`.`deposit`                                  AS `deposit`
from `bookdb`.`record` `r`
         join `bookdb`.`book` `b`
         join `bookdb`.`member` `m`
         join `bookdb`.`membertype` `mt`
where ((`r`.`memberId` = `m`.`id`) and (`r`.`bookId` = `b`.`id`) and (`m`.`typeId` = `mt`.`id`));

