create definer = root@localhost trigger TG_4
    after delete
    on teacher
    for each row
BEGIN
DELETE FROM operator WHERE ope_id = old.ope_id;
END;

