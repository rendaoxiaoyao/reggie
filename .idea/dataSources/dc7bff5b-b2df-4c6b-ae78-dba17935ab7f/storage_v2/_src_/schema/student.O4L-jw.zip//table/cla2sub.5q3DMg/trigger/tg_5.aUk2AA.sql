create definer = root@localhost trigger TG_5
    after delete
    on cla2sub
    for each row
BEGIN
DELETE FROM score WHERE stu_id IN (SELECT stu_id FROM student WHERE cla_id = old.cla_id ) AND sub_id = old.sub_id;
END;

