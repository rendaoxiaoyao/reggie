create definer = root@localhost trigger TG_8
    before delete
    on major
    for each row
BEGIN
DELETE FROM operator WHERE ope_id IN(SELECT ope_id FROM student WHERE cla_id IN(SELECT cla_id FROM classes WHERE maj_id = old.maj_id));
END;

