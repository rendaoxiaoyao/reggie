create definer = root@localhost trigger TG_7
    before delete
    on classes
    for each row
BEGIN
DELETE FROM operator WHERE ope_id IN (SELECT ope_id FROM student WHERE cla_id = old.cla_id);
END;

