create definer = root@localhost trigger TG_3
    after delete
    on student
    for each row
BEGIN
DELETE FROM operator WHERE ope_id = old.ope_id;
END;

